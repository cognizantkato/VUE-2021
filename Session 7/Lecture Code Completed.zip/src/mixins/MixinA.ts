import { defineComponent } from "@vue/runtime-core";

const MixinA = defineComponent({
  data() {
    return {
      fullName: 'Don Jasa'
    }
  }
})

export default MixinA