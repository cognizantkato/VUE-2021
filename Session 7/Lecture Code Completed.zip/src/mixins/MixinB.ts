import { defineComponent } from "vue"

const MixinB = defineComponent({
  data() {
    return {
      lastName: 'Jasa'
    }
  }
})

export default MixinB