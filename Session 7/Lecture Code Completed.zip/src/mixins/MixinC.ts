import { defineComponent } from "vue"

const MixinC = defineComponent({
  data() {
    return {
      firstName: 'Don'
    }
  }
})

export default MixinC