<template>
  <h1>The Composition API</h1>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

const App = defineComponent({
  
});

export default App;
</script>

<style>
#app {
  font-family: Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  margin-top: 60px;
}

h1 {
  color: #2c3e50;
}
</style>
