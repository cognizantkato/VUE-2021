<template>
  Orders
</template>

<script lang="ts">
import { defineComponent } from 'vue'

const Orders = defineComponent({});

export default Orders;
</script>
